package servicodetransporte;

public interface Transportes {
	
	public double calculaPreco(int distancia);
	
}
